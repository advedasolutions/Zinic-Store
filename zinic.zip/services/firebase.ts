// Firebase Authentication service rolled back by user request.
export const auth = null;